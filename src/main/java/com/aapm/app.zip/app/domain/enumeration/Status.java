package com.aapm.app.domain.enumeration;

/**
 * The Status enumeration.
 */
public enum Status {
    Ativo,
    Inativo,
    Bloqueado,
}
