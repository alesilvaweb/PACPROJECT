package com.aapm.app.domain.enumeration;

/**
 * The StatusArquivo enumeration.
 */
public enum StatusArquivo {
    Carregado,
    Processado,
    Arquivado,
    Erro,
}
