package com.aapm.app.domain.enumeration;

/**
 * The TipoContato enumeration.
 */
public enum TipoContato {
    Telefone,
    Email,
}
