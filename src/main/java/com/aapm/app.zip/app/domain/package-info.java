/**
 * JPA domain objects.
 */
package com.aapm.app.domain;
