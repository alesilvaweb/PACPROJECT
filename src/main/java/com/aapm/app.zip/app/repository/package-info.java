/**
 * Spring Data JPA repositories.
 */
package com.aapm.app.repository;
