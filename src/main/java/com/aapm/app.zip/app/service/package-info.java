/**
 * Service layer beans.
 */
package com.aapm.app.service;
