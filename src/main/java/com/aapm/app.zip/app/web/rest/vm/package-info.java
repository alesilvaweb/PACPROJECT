/**
 * View Models used by Spring MVC REST controllers.
 */
package com.aapm.app.web.rest.vm;
