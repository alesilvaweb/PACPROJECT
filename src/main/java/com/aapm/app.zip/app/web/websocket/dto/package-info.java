/**
 * Data Access Objects used by WebSocket services.
 */
package com.aapm.app.web.websocket.dto;
